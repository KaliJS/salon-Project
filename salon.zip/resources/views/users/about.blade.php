@extends('layouts.index')

@section('content')

		
            <!-- CONTENT START -->
        <div class="page-content">
        
            <!-- INNER PAGE BANNER -->
            <div class="wt-bnr-inr overlay-wraper bg-center" style="background-image:url({{url('users/images/31.jpg')}});">
              <div class="overlay-main site-bg-secondry opacity-07"></div>
                <div class="container">
                    <div class="wt-bnr-inr-entry">
                      <div class="banner-title-outer">
                          <div class="banner-title-name">
                            <h2 class="site-text-primary">About Us</h2>
                            </div>
                        </div>
                        <!-- BREADCRUMB ROW -->                            
                        
                            <div>
                                <ul class="wt-breadcrumb breadcrumb-style-2">
                                    <li><a href="javascript:void(0);">Home</a></li>
                                    <li>About 1</li>
                                </ul>
                            </div>
                        
                        <!-- BREADCRUMB ROW END -->                        
                    </div>
                </div>
            </div>
            <!-- INNER PAGE BANNER END -->

            <!-- ABOUT SECTION START -->
            <div class="section-full welcome-section-outer">
              <div class="welcome-section-top shadow-lg bg-white p-tb80">
                    <div class="container">
                      <div class="row">
                          <div class="col-lg-7 col-md-12">
                                <div class="welcom-to-section">
                                    <!-- TITLE START-->
                                    <div class="left wt-small-separator-outer">
                                        <div class="wt-small-separator">
                                            <div class="sep-leaf-left"><img src="{{asset('users/images/sep-leaf-left.png')}}" alt=""></div>
                                            <div>Welcome to</div>
                                            <div class="sep-leaf-right"><img src="{{asset('users/images/sep-leaf-right.png')}}" alt=""></div>
                                        </div>
                                    </div>
                                    <h2>Our Salon is Most Popular, Clean and Recommended Hair Salon</h2>
                                    <!-- TITLE END-->
                                    <p>We have a passion for promoting healthy, balanced and beautiful living. Offering massage, Acupuncture, Laser Skincare, fitness classes and more, we emphasize preventive care, stress management, and personal growth. While you may find a visit with us to be a spa-like, relaxing and pampering experience, </p> 
                                    
                                    <div class="welcom-to-section-bottom d-flex justify-content-between">
                                        <div class="welcom-btn-position m-t20"><a href="javascript:;" class="site-button site-btn-effect">More About</a></div>
                                        <img src="{{asset('users/images/sign.png')}}" alt="">
                                    </div>   
                                    <div class="hilite-large-title">
                                        <span>Welcome</span>
                                    </div>                              
                                </div>
                            </div>
                            <div class="col-lg-5 col-md-12">
                              <div class="img-colarge">
                                  <div class="colarge-1"><img src="{{asset('users/images/s1.jpg')}}" alt=""></div>
                                    <div class="colarge-2"><img src="{{asset('users/images/s2.jpg')}}" alt=""></div>
                                    <div class="colarge-3 slide-right"><img src="{{asset('users/images/s3.jpg')}}" alt=""></div>
                                </div>
                            </div>
                        </div>
                    </div> 
                </div>
                                       
                <div class="welcome-section-bottom overlay-wraper bg-cover bg-no-repeat " style="background-image:url({{url('users/images/bg-2.jpg')}});"> 
                    <div class="overlay-main bg-orange-light opacity-09"></div>
                        <div class="container welcome-section-bottom-space p-t80 p-b50">
                            <div class="row">
                                <div class="col-lg-7 col-md-12">
                                    <div class="video-section-outer mfp-gallery">
                                        <!--Fade slider-->
                                        <div class="owl-carousel home-video-slider owl-btn-top-left light-next-prev m-b30">
                                        
                                            <div class="item">
                                                <div class="video-section">
                                                    <img src="{{asset('users/images/pic1.jpg')}}" alt="">
                                                     <a href="https://player.vimeo.com/video/34741214?color=ffffff&amp;title=0&amp;byline=0&amp;portrait=0" class="mfp-video play-now">
                                                        <i class="icon fa fa-play"></i>
                                                        <span class="ripple"></span>
                                                    </a>                                              
                                                </div>      
                                            </div>  
                                            
                                            <div class="item">
                                                <div class="video-section">
                                                    <img src="{{asset('users/images/pic4.jpg')}}" alt="">
                                                </div>
                                            </div> 
                                            
                                            <div class="item">
                                                <div class="video-section">
                                                    <img src="{{asset('users/images/pic1.jpg')}}" alt="">
                                                     <a href="https://player.vimeo.com/video/34741214?color=ffffff&amp;title=0&amp;byline=0&amp;portrait=0" class="mfp-video play-now">
                                                        <i class="icon fa fa-play"></i>
                                                        <span class="ripple"></span>
                                                    </a>                                              
                                                </div>      
                                            </div>                                                                                                                           
                                        
                                        </div> <!--fade slider END-->                                
                                    </div>
                                </div>
                                <div class="col-lg-5 col-md-12">
                                    <div class="about-section-outer">
                                        <!-- TITLE START-->
                                        <div class="left wt-small-separator-outer">
                                            <div class="wt-small-separator">
                                                <div class="sep-leaf-left"><img src="{{asset('users/images/sep-leaf-left.png')}}" alt=""></div>
                                                <div>Welcome to</div>
                                                <div class="sep-leaf-right"><img src="{{asset('users/images/sep-leaf-right.png')}}" alt=""></div>
                                            </div>
                                        </div>
                                        <h2>Our Video Presentation</h2>
                                        <!-- TITLE END-->
                                        
                                        <p>Professional stylist tell me how beautiful it is to hide or emphasize your image. the beauty lies in the details of trends, the choice of fabrics and colors. guarantee
you a unique result. We will provide you with the highest quality of our service</p>

                                        <div class="counter-outer p-t10">                            
                                            
                                            <div class="row justify-content-center">
                                                    
                                                <div class="col-lg-4 col-md-4 m-b30 ">
                                                    <div class="wt-icon-box-wraper center bg-no-repeat bg-top-center" style="background-image:url({{url('users/images/count-bg.png')}});">
                                                        <h2 class="counter site-text-secondry">23</h2>
                                                        <span class="site-text-secondry title-style-2">Awards</span>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-lg-4 col-md-4 m-b30">
                                                    <div class="wt-icon-box-wraper center bg-no-repeat bg-top-center" style="background-image:url({{url('users/images/count-bg.png')}})">
                                                        <h2 class="counter site-text-secondry">14</h2>
                                                        <span class="site-text-secondry title-style-2">Years</span>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-lg-4 col-md-4 m-b30">
                                                    <div class="wt-icon-box-wraper center bg-no-repeat bg-top-center" style="background-image:url({{url('users/images/count-bg.png')}});">
                                                        <h2 class="counter site-text-secondry">26</h2>
                                                        <span class="site-text-secondry title-style-2">Experts</span>
                                                    </div>
                                                </div>
       
                                            </div>                            
                                        
                                        </div>   
                                    
                                    </div>
                                </div>
                            </div>
                        </div>
  
                </div>                                        

            </div>   
            <!-- ABOUT SECTION  SECTION END -->   
                                                  
            <!-- ABOUT STORY SECTION START -->
            <div class="section-full  p-t80 p-b80  overlay-wraper" style="background-image:url({{url('users/images/bg-2.jpg')}});">
              <div class="overlay-main site-bg-primary opacity-09"></div>
                <div class="container">
                                    
                    <div class="section-content">
                    
                        <div class="info-video-section text-white text-center">
                                <div class="info-video-title max-w700 ml-auto mr-auto">
                                  <h4>New york since 2012 </h4>
                                    <h2 class="wt-title m-t0">About Our Story</h2>
                                    <p>Praesent id odio quis massa aliquet dictum ut eget erat. Aliquam erat volutpat. Pellentesque sit amet congue tellus.</p>
                                    <a href="javascript:;" class="site-button site-btn-effect">Make An Appointment</a>
                                </div>
                        </div>
                                               
                    </div>
                    
        </div>
            </div>
            <!-- ABOUT STORY SECTION END --> 
            
            <!-- ALL SERVICES START -->
            <div class="section-full p-t80 p-b50 bg-no-repeat bg-bottom-right" style="background-image:url(images/background/bubble-bg.png)">
                <div class="container">
                    <div class="section-content">
                    
                    <!-- TITLE START-->
                        <div class="center wt-small-separator-outer section-head">
                            <div class="wt-small-separator">
                                <div class="sep-leaf-left"><img src="{{asset('users/images/sep-leaf-left.png')}}" alt=""></div>
                                <div>Save 20% On Haircuts</div>
                                <div class="sep-leaf-right"><img src="{{asset('users/images/sep-leaf-right.png')}}" alt=""></div>
                            </div>
                            <h2 data-title="Services">Our Services</h2>
                        </div>
                    <!-- TITLE END-->
                               
                        <div class="row d-flex justify-content-center">
                        
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="icon-circle-box v-icon-effect bg-orange-light">
                                    <div class="wt-icon-box-wraper center p-b50  m-b30 corner-radius">
                                        <div class="icon-lg  m-b20 icon-circle">
                                            <span class="icon-cell">
                                                <i class="fa fa-users "></i>
                                            </span>
                                        </div>
                                        <div class="icon-content relative">
                                            <h3 class="wt-tilte">Classic Haircut</h3>
                                            <p>Proin dapibus nisl ornare diam varius mpus. Aenean a quam luctus, finibus tellus ut, convallis eros.</p>
                                            <a href="javascript:;" class="site-button-link black">Read More</a>
                                        </div>
                                    </div>
                                </div>                          
                            </div>
                            
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="icon-circle-box  v-icon-effect bg-orange-light">
                                    <div class="wt-icon-box-wraper center p-b50 m-b30 corner-radius">
                                        <div class="icon-lg  m-b20  icon-circle">
                                            <span class="icon-cell">
                                                <i class="fa fa-users "></i>
                                            </span>
                                        </div>
                                        <div class="icon-content relative">
                                            <h3 class="wt-tilte">Hair Treatment</h3>
                                            <p>Faucibus ante, in porttitor tellus blandit et. Phasellus tincidunt metus lectus sollicitudin feugiat pharetra.</p>
                                            <a href="javascript:;" class="site-button-link black">Read More</a>
                                        </div>
                                    </div>
                                </div>                          
                            </div>
                            
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="icon-circle-box v-icon-effect bg-orange-light">
                                    <div class="wt-icon-box-wraper center p-b50 m-b30  corner-radius">
                                    <div class="icon-lg  m-b20  icon-circle">
                                        <span class="icon-cell">
                                            <i class="fa fa-users "></i>
                                        </span>
                                    </div>
                                    <div class="icon-content relative">
                                        <h3 class="wt-tilte">Hair Wash</h3>
                                        <p>Maecenas pulvinar, risus in facilisis dignissim, quam nisi hendrerit nulla, id vestibulum metus nullam.</p>
                                        <a href="javascript:;" class="site-button-link black">Read More</a>
                                    </div>
                                </div>
                                </div>                          
                            </div>
                            
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="icon-circle-box v-icon-effect bg-orange-light">
                                    <div class="wt-icon-box-wraper center p-b50  m-b30 corner-radius">
                                        <div class="icon-lg  m-b20 icon-circle">
                                            <span class="icon-cell">
                                                <i class="fa fa-users "></i>
                                            </span>
                                        </div>
                                        <div class="icon-content relative">
                                            <h3 class="wt-tilte">Hair Color</h3>
                                            <p>Proin dapibus nisl ornare diam varius mpus. Aenean a quam luctus, finibus tellus ut, convallis eros.</p>
                                            <a href="javascript:;" class="site-button-link black">Read More</a>
                                        </div>
                                    </div>
                                </div>                          
                            </div>
                            
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="icon-circle-box  v-icon-effect bg-orange-light">
                                    <div class="wt-icon-box-wraper center p-b50 m-b30 corner-radius">
                                        <div class="icon-lg   m-b20  icon-circle">
                                            <span class="icon-cell">
                                                <i class="fa fa-users "></i>
                                            </span>
                                        </div>
                                        <div class="icon-content relative">
                                            <h3 class="wt-tilte">Hair Stylist</h3>
                                            <p>Faucibus ante, in porttitor tellus blandit et. Phasellus tincidunt metus lectus sollicitudin feugiat pharetra.</p>
                                            <a href="javascript:;" class="site-button-link black">Read More</a>
                                        </div>
                                    </div>
                                </div>                          
                            </div>
                            
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="icon-circle-box v-icon-effect bg-orange-light">
                                    <div class="wt-icon-box-wraper center p-b50   corner-radius">
                                    <div class="icon-lg  m-b20  icon-circle">
                                        <span class="icon-cell">
                                            <i class="fa fa-users "></i>
                                        </span>
                                    </div>
                                    <div class="icon-content relative">
                                        <h3 class="wt-tilte">Hair Extension</h3>
                                        <p>Maecenas pulvinar, risus in facilisis dignissim, quam nisi hendrerit nulla, id vestibulum metus nullam.</p>
                                        <a href="javascript:;" class="site-button-link black">Read More</a>
                                    </div>
                                </div>
                                </div>                          
                            </div>                              
                                                                                
                        </div>
                    </div>
                </div>
            </div>   
            <!-- ALL SERVICES SECTION END -->            
            
            <!-- CLIENT LOGO SECTION START -->
            <div class="section-full bg-orange-light">
                <div class="container">
                    <div class="section-content" >
                    
                        <!-- TESTIMONIAL 4 START ON BACKGROUND -->   
                        <div class="section-content">
                             <div class="section-content p-tb10 owl-btn-vertical-center">
                                <div class="owl-carousel home-client-carousel-2 m-b50 m-t50">
                                
                                    <div class="item">
                                        <div class="ow-client-logo">
                                            <div class="client-logo client-logo-media">
                                            <a href="javascript:void(0);"><img src="{{asset('users/images/w1.png')}}" alt=""></a></div>
                                        </div>
                                    </div>
                                    
                                    <div class="item">
                                        <div class="ow-client-logo">
                                            <div class="client-logo client-logo-media">
                                            <a href="javascript:void(0);"><img src="{{asset('users/images/w2.png')}}" alt=""></a></div>
                                        </div>
                                    </div>
                                    
                                    <div class="item">
                                        <div class="ow-client-logo">
                                            <div class="client-logo client-logo-media">
                                            <a href="javascript:void(0);"><img src="{{asset('users/images/w3.png')}}" alt=""></a></div>
                                        </div>
                                    </div>
                                    
                                    <div class="item">
                                        <div class="ow-client-logo">
                                            <div class="client-logo client-logo-media">
                                            <a href="javascript:void(0);"><img src="{{asset('users/images/w4.png')}}" alt=""></a></div>
                                        </div>
                                    </div>
                                    
                                    <div class="item">
                                        <div class="ow-client-logo">
                                            <div class="client-logo client-logo-media">
                                            <a href="javascript:void(0);"><img src="{{asset('users/images/w5.png')}}" alt=""></a></div>
                                        </div>
                                    </div>
                                    
                                    <div class="item">
                                        <div class="ow-client-logo">
                                            <div class="client-logo client-logo-media">
                                            <a href="javascript:void(0);"><img src="{{asset('users/images/w6.png')}}" alt=""></a></div>
                                        </div>
                                    </div>
                                    
                                    <div class="item">
                                        <div class="ow-client-logo">
                                            <div class="client-logo client-logo-media">
                                            <a href="javascript:void(0);"><img src="{{asset('users/images/w2.png')}}" alt=""></a></div>
                                        </div>
                                    </div>
                                    
                                    <div class="item">
                                        <div class="ow-client-logo">
                                            <div class="client-logo client-logo-media">
                                            <a href="javascript:void(0);"><img src="{{asset('users/images/w2.png')}}" alt=""></a></div>
                                        </div>
                                    </div>
                                    
                                    <div class="item">
                                        <div class="ow-client-logo">
                                            <div class="client-logo client-logo-media">
                                            <a href="javascript:void(0);"><img src="{{asset('users/images/w1.png')}}" alt=""></a></div>
                                        </div>
                                    </div>
                                    
                                    <div class="item">
                                        <div class="ow-client-logo">
                                            <div class="client-logo client-logo-media">
                                            <a href="javascript:void(0);"><img src="{{asset('users/images/w1.png')}}" alt=""></a></div>
                                        </div>
                                    </div>
                                    
                                    <div class="item">
                                        <div class="ow-client-logo">
                                            <div class="client-logo client-logo-media">
                                            <a href="javascript:void(0);"><img src="{{asset('users/images/w1.png')}}" alt=""></a></div>
                                        </div>
                                    </div>
                                    
                                    <div class="item">
                                        <div class="ow-client-logo">
                                            <div class="client-logo client-logo-media">
                                            <a href="javascript:void(0);"><img src="{{asset('users/images/w1.png')}}" alt=""></a></div>
                                        </div>
                                    </div>  
                                    
                                    <div class="item">
                                        <div class="ow-client-logo">
                                            <div class="client-logo client-logo-media">
                                            <a href="javascript:void(0);"><img src="{{asset('users/images/w1.png')}}" alt=""></a></div>
                                        </div>
                                    </div>
                                    
                                    <div class="item">
                                        <div class="ow-client-logo">
                                            <div class="client-logo client-logo-media">
                                            <a href="javascript:void(0);"><img src="images/client-logo/w2.png" alt=""></a></div>
                                        </div>
                                    </div>
                                    
                                    <div class="item">
                                        <div class="ow-client-logo">
                                            <div class="client-logo client-logo-media">
                                            <a href="javascript:void(0);"><img src="{{asset('users/images/w1.png')}}" alt=""></a></div>
                                        </div>
                                    </div>
                                    
                                    <div class="item">
                                        <div class="ow-client-logo">
                                            <div class="client-logo client-logo-media">
                                            <a href="javascript:void(0);"><img src="{{asset('users/images/w1.png')}}" alt=""></a></div>
                                        </div>
                                    </div>
                                    
                                    <div class="item">
                                        <div class="ow-client-logo">
                                            <div class="client-logo client-logo-media">
                                            <a href="javascript:void(0);"><img src="{{asset('users/images/w1.png')}}" alt=""></a></div>
                                        </div>
                                    </div>
                                    
                                    <div class="item">
                                        <div class="ow-client-logo">
                                            <div class="client-logo client-logo-media">
                                            <a href="javascript:void(0);"><img src="{{asset('users/images/w1.png')}}" alt=""></a></div>
                                        </div>
                                    </div>                                                                      
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- CLIENT LOGO  SECTION End -->                
            
        </div>
        <!-- CONTENT END -->

@stop
  