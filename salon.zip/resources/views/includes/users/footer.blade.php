<!-- FOOTER START -->
        <footer class="site-footer footer-large footer-dark text-white" style="display: block; height: 375px;">
            
            <!-- FOOTER BLOCKES START -->  
            <div class="footer-top  dot2-left-top-img">
                <div class="container">
                    <div class="row">
                    
                        <div class="col-lg-6 col-md-12 col-sm-12">  
                            <div class="widget widget_about">
                                <div class="logo-footer clearfix p-b15">
                                    <a href="http://thewebmax.com/saloni/index.html"><img src="{{asset('users/images/logo-light.png')}}" alt=""></a>
                                </div>
                                <p>Lorem ipsum dolor sit amet, consectetur adip iscing elit, sed do eiusmod temporin cididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.eiusmod tempo.</p>
                               
                                <div class="newsletter-input">
                                  <div class="input-group">
                                    <input id="email" type="text" class="form-control" name="email" placeholder="Enter your email">
                                    <div class="input-group-append">
                                      <button type="submit" class="input-group-text nl-search-btn text-black site-bg-secondry">Subscribe</button>
                                    </div>
                                  </div>
                                </div>
                        
                            </div>
                            
                        </div> 

						<div class="col-lg-3 col-md-6 col-sm-12">
                            <div class="widget widget_services">
                                <h4 class="widget-title">Useful links</h4>
							    <ul>
                                    <li><a href="javascript:;">About</a><a href="javascript:;">Portfolio</a></li>
                                    <li><a href="javascript:;">Pricing Plan </a><a href="javascript:;">Contact Us</a></li>
                                    <li><a href="javascript:;">Career </a><a href="javascript:;">Policy</a></li>
                                    <li><a href="javascript:;">Our Team </a><a href="javascript:;">FAQ's</a></li>
                                    <li><a href="javascript:;">Services </a><a href="javascript:;">About</a></li>
                                </ul>
                            </div>
                                                    
                        </div> 

                        <div class="col-lg-3 col-md-6 col-sm-12">
                            <div class="widget recent-posts-entry">
                                <h4 class="widget-title">Contact Us</h4>
                                  <ul class="widget_address"> 
                                  	<li><i class="fa fa-map-marker"></i>San Francisco City Hall, San Francisco, CA</li>
                                    <li><i class="fa fa-envelope"></i>contact123@gmail.com</li>
                                    <li> <i class="fa fa-phone"></i>(654) 321-7654 </li>
                                </ul>  
                            </div>           
                        </div>
                                              
                    </div>
                </div>
            </div>
            <!-- FOOTER COPYRIGHT -->
            
            <div class="footer-bottom">
              <div class="container">
                <div class="wt-footer-bot-left d-flex justify-content-between">
                    <span class="copyrights-text">Copyright © 2019 Thewebmax</span>
                    <ul class="copyrights-nav"> 
                        <li><a href="javascript:void(0);">Terms  &amp; Condition</a></li>
                        <li><a href="javascript:void(0);">Privacy Policy</a></li>
                        <li><a href="http://thewebmax.com/saloni/contact-1.html">Contact Us</a></li>
                    </ul>     
                </div>
              </div>   
            </div>   


        </footer>
        <!-- FOOTER END -->