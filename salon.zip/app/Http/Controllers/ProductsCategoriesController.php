<?php

namespace App\Http\Controllers;

use App\Models\ProductsCategories;
use Illuminate\Http\Request;
use App\Models\Branch;
use Redirect;
use Auth;

class ProductsCategoriesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $categories = ProductsCategories::orderBy('name')->get();
        return view('admin.Products.products-categories',compact('categories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.Products.create-products-categories');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required'
        ]);

        $input=$request->all();
        $input['branch_id']=\Auth::user()->id;
        ProductsCategories::create($input);
        
        return redirect()->route('products-categories.index')
            ->with('success', 'Category created Successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ProductsCategories  $productsCategories
     * @return \Illuminate\Http\Response
     */
    public function show(ProductsCategories $productsCategories)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ProductsCategories  $productsCategories
     * @return \Illuminate\Http\Response
     */
    public function edit(ProductsCategories $productsCategories)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ProductsCategories  $productsCategories
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProductsCategories $productsCategories)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ProductsCategories  $productsCategories
     * @return \Illuminate\Http\Response
     */
    public function destroy(ProductsCategories $productsCategories)
    {
        //
    }


     public function editCategory($id){
        try{
            $category=ProductsCategories::find($id);
            return view('admin.Products.edit-products-categories', compact('category'));
            
        }catch(\Exception $e){
            return Redirect::back()->with('error',$e->getMessage());
        }
        
    }

    public function updatecategory(Request $request,$id){

        try{
            $input = $request->all();
            unset($input['_token']);
            $update=ProductsCategories::where('id',$id)->update($input);
            return Redirect::back()->with('success','Category Updated Successfully!');
    
        }catch(\Exception $e){
            return Redirect::back()->with('error',$e->getMessage());
        }
    }

    public function destroyCategory(Request $request , $id){
        try{
            ProductsCategories::where('id', $id)->delete();
            return Redirect::back()->with('success','Category Deleted Successfully!');
    
        }catch(\Exception $e){
            return Redirect::back()->with('error',$e->getMessage());
        }
    }
}
