<?php

namespace App\Http\Controllers;

use App\Models\ServicesSubCategories;
use Illuminate\Http\Request;
use Auth;

class ServicesSubCategoriesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    
    public function index()
    {
       return view('admin.Services.services-subcategories'); 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories=Category::where('branch_id',$main_branch_id)->get(['id','name']);
        return view('',compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ServicesSubCategories  $servicesSubCategories
     * @return \Illuminate\Http\Response
     */
    public function show(ServicesSubCategories $servicesSubCategories)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ServicesSubCategories  $servicesSubCategories
     * @return \Illuminate\Http\Response
     */
    public function edit(ServicesSubCategories $servicesSubCategories)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ServicesSubCategories  $servicesSubCategories
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ServicesSubCategories $servicesSubCategories)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ServicesSubCategories  $servicesSubCategories
     * @return \Illuminate\Http\Response
     */
    public function destroy(ServicesSubCategories $servicesSubCategories)
    {
        //
    }
}
