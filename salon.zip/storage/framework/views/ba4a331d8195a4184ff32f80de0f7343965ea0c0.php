

<?php $__env->startSection('content'); ?>

		
            <!--/app header--> 
            <!--Page header-->
            <div class="page-header">
              <div class="page-leftheader">
                <h4 class="page-title mb-0">Hi! Welcome Back</h4>
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="#"><i class="angle fa fa-angle-right mr-2"></i>Products</a>
                  </li>  
                </ol>
              </div>
            </div>
            <!--End Page header-->
            
            <div class="row">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-header">
                    <h3 class="card-title">Add Products</h3>
                  </div>
                  <div class="card-body p-6">


                    <ul class="nav nav-tabs" role="tablist">
                      <li role="presentation" class="active mr-2"><a href="#home" class="btn btn-primary text-white" aria-controls="home" role="tab" data-toggle="tab"><span>Add Products</span></a></li>
                      <li role="presentation" class="mr-2"><a href="#profile" class="btn btn-primary text-white" aria-controls="profile" role="tab" data-toggle="tab"><span>Add Category</span></a></li>
                      <li role="presentation" class=" mr-2"><a href="#messages" class="btn btn-primary text-white"aria-controls="messages" role="tab" data-toggle="tab"><span>Add Genric Name</span></a></li>
                      <li role="presentation"><a href="#settings" class="btn btn-primary text-white" aria-controls="settings" role="tab" data-toggle="tab"><span>Add Brands</span></a></li>
                      
                    </ul>
        
        
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane mt-3 active" id="home">
                          <div class="card-body">
                          <form class="form-horizontal">
                            <div class="form-group row">
                              <label for="inputName" class="col-md-3 form-label">IDH No</label>
                              <div class="col-md-9">
                                <input type="number" class="form-control" id="inputDesignation" placeholder="IDH No">
                              </div>
                            </div>
                            <div class="form-group row">
                              <label for="inputName" class="col-md-3 form-label">HSN</label>
                              <div class="col-md-9">
                                <input type="text" class="form-control" id="inputDesignation" placeholder="HSN">
                              </div>
                            </div>
                            <div class="form-group row ">
                              <label class="col-md-3 form-label">Brand</label>
                              <div class="col-md-9">
                                <select class="form-control " tabindex="-1" aria-hidden="true">
                                  <option>brand1</option>
                                  <option>brand2</option>
                                </select>
                              </div>
                            </div>
                            <div class="form-group row ">
                              <label class="col-md-3 form-label">Category</label>
                              <div class="col-md-9">
                                <select class="form-control " tabindex="-1" aria-hidden="true">
                                  <option>cat1</option>
                                  <option>cat2</option>
                                </select>
                              </div>
                            </div>
                            <div class="form-group row ">
                              <label class="col-md-3 form-label">Genric Name</label>
                              <div class="col-md-9">
                                <select class="form-control " tabindex="-1" aria-hidden="true">
                                  <option>gen1</option>
                                  <option>gen2</option>
                                </select>
                              </div>
                            </div>
                            
                            <div class="form-group row">
                              <label for="inputName" class="col-md-3 form-label">Product Description</label>
                              <div class="col-md-9">
                                <input type="text" class="form-control" id="inputDesignation" placeholder="Description">
                              </div>
                            </div>

                            <div class="form-group mb-0 mt-4 row justify-content-end">
                              <div class="col-md-9">
                                <button type="submit" class="btn btn-primary">Create</button>
                                
                              </div>
                            </div>
                          </form>
                        </div>
                      </div>
                        <div role="tabpanel" class="tab-pane mt-3" id="profile">
                          <div class="form-group">
                            <label class="col-md-3 form-label">Category</label>
                            <div class="input-group">
                              <input type="text" class="form-control" placeholder="Category">
                              <span class="input-group-append">
                                <button class="btn btn-primary" type="button">Add</button>
                              </span>
                            </div>
                          </div>
                        </div>
                        <div role="tabpanel" class="tab-pane mt-3" id="messages">
                          <div class="form-group">
                            <label class="col-md-3 form-label">Genric Name</label>
                            <div class="input-group">
                              <input type="text" class="form-control" placeholder="Enter Genric Name">
                              <span class="input-group-append">
                                <button class="btn btn-primary" type="button">Add</button>
                              </span>
                            </div>
                          </div>
                        </div>
                        <div role="tabpanel" class="tab-pane mt-3" id="settings">
                          <div class="form-group">
                            <label class="col-md-3 form-label">Brand</label>
                            <div class="input-group">
                              <input type="text" class="form-control" placeholder="Enter Brand">
                              <span class="input-group-append">
                                <button class="btn btn-primary" type="button">Add</button>
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                  </div>
                </div>
              </div>
            </div>
            
           
            

          </div>
        </div>

<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\salon\resources\views/admin/Products/products.blade.php ENDPATH**/ ?>