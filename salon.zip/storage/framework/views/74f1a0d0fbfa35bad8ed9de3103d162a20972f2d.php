 <!-- HEADER START -->
        <header class="site-header header-style-1 mobile-sider-drawer-menu">
            
            <div class="sticky-wrapper" style="height: 91px;"><div class="sticky-header main-bar-wraper  navbar-expand-lg is-fixed">
                <div class="main-bar">
                    <div class="container">
                        <div class="logo-header">
                            <div class="logo-header-inner logo-header-one">
                                <a href="http://thewebmax.com/saloni/index.html">
                                <img src="<?php echo e(asset('users/images/logo-dark.png')); ?>" alt="">
                                </a>
                            </div>
                        </div>
                        <!-- NAV Toggle Button -->

                        <button id="mobile-side-drawer" data-target=".header-nav" data-toggle="collapse" type="button" class="navbar-toggler collapsed">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar icon-bar-first"></span>
                            <span class="icon-bar icon-bar-two"></span>
                            <span class="icon-bar icon-bar-three"></span>
                        </button>

                         
                        <div class="extra-nav header-2-nav">
                            <div class="extra-cell">
                                <a href="javascript:;" class="Call-btn site-text-primary">+41 43 542 65 91</a>
                            </div>
                         </div>
                         
                        <!-- MAIN Vav -->
                        <div class="nav-animation header-nav navbar-collapse collapse d-flex justify-content-center">
                    
                            <ul class=" nav navbar-nav">
                                
                                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                                <li><a href="<?php echo e(url('/about')); ?>">About Us</a></li>
                                <li><a href="<?php echo e(url('/services')); ?>">Services</a></li>
                                <li><a href="<?php echo e(url('/gallery')); ?>">Gallery</a></li>
                                <li><a href="<?php echo e(url('/covid')); ?>">Covid Care</a></li>
                                <li><a href="<?php echo e(url('/contact')); ?>">Contact us</a></li>                                
                            </ul>

                        </div>
                        
                    </div>
                </div>
            </div></div>
            
        </header>
        <!-- HEADER END --><?php /**PATH C:\xampp\htdocs\salon\resources\views/includes/users/header.blade.php ENDPATH**/ ?>