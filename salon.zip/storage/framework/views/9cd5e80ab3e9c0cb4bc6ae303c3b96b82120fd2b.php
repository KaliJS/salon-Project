<footer class="footer">
        <div class="container">
          <div class="row align-items-center flex-row-reverse">
            <div class="col-md-12 col-sm-12 text-center">
              Copyright © 2020 <a href="Vertical-IconSidedar-Light/#">Project</a> Designed by <a href="Vertical-IconSidedar-Light/#">...2020...</a> All rights reserved.
            </div>
          </div>
        </div>
      </footer><?php /**PATH C:\xampp\htdocs\salon\resources\views/includes/footer.blade.php ENDPATH**/ ?>