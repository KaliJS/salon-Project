<!-- FOOTER START -->
        <footer class="site-footer footer-large footer-dark text-white" style="display: block; height: 375px;">
            
            <!-- FOOTER BLOCKES START -->  
            <div class="footer-top  dot2-left-top-img">
                <div class="container">
                    <div class="row">
                    
                        <div class="col-lg-6 col-md-12 col-sm-12">  
                            <div class="widget widget_about">
                                <div class="logo-footer clearfix p-b15">
                                    <a href="http://thewebmax.com/saloni/index.html"><img src="{{asset('users/images/logo-light.png')}}" alt=""></a>
                                </div>
                                <p>Welcome to Ocean Blue Wellness Located in multiple Location in Bengaluru, where our expirienced team will help u connect with yourself and nature whilst elevating how you feel about your hair, skin and soul.                                 </p>
                               
                                <div class="newsletter-input">
                                  <div class="input-group">
                                    <input id="email" type="text" class="form-control" name="email" placeholder="Enter your email">
                                    <div class="input-group-append">
                                      <button type="submit" class="input-group-text nl-search-btn text-black site-bg-secondry">Subscribe</button>
                                    </div>
                                  </div>
                                </div>
                        
                            </div>
                            
                        </div> 

						<div class="col-lg-3 col-md-6 col-sm-12">
                            <div class="widget widget_services">
                                <h4 class="widget-title">Useful links</h4>
							    <ul>
                                    <li><a href="javascript:;">Our Branches</a><a href="{{url('/about')}}">About Us</a></li>
                                    <li><a href="javascript:;">Book Now </a><a href="{{url('/service')}}">Our Services</a></li>
                                    <li><a href="{{url('/gallery')}}">Gallery </a><a href="{{url('/contact')}}">Contact Us</a></li>
                                    
                                </ul>
                            </div>
                                                    
                        </div> 

                        <div class="col-lg-3 col-md-6 col-sm-12">
                            <div class="widget recent-posts-entry">
                                <h4 class="widget-title">Contact Us</h4>
                                  <ul class="widget_address"> 
                                  	<li><i class="fa fa-map-marker"></i>No 1, Balarama Layout, Krishna Garden Main Road, Near Happy Home Super Market, Rajarajeshwari Nagar, Bengaluru - 560098 </li>
                                    <li>Shop No 6 & 7, Opp Vasthugreens Apartment, Near Gudde Anjineya Temple, Hemmegepura Road, Kengeri Ward No 198, Bengaluru - 560060 </li>
                                    <li><i class="fa fa-envelope"></i>info@obw1.com</li>
                                    <li> <i class="fa fa-phone"></i>For Appointment Call 9972011222/9108031222</li>
                                </ul>  
                            </div>           
                        </div>
                                              
                    </div>
                </div>
            </div>
            <!-- FOOTER COPYRIGHT -->
            
            <div class="footer-bottom">
              <div class="container">
                <div class="wt-footer-bot-left d-flex justify-content-between">
                    <span class="copyrights-text">Copyright © 2020 Ocean Blue Wellness - Powered by Codesquerry Pvt Ltd</span>
                        
                </div>
              </div>   
            </div>   


        </footer>
        <!-- FOOTER END -->